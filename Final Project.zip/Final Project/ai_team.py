from ai_operative import AIOperative

class AITeam:
    def __init__(self, count=3):
        self.operatives = []
        for i in range(count):
            self.operatives.append(
                AIOperative(name=f"AI Operative {i+1}")
            )

    def is_team_alive(self):
        return any(op.health > 0 for op in self.operatives)

    def get_alive_operatives(self):
        return [op for op in self.operatives if op.health > 0]

    def choose_target_for_ai(self, player_team):
        alive = player_team.get_alive_operatives()
        if not alive:
            return None
        return alive[0]
