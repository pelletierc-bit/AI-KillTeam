class PlayerTeam:
    def __init__(self, count=1):
        self.operatives = []
        for i in range(count):
            self.operatives.append({
                "name": f"Player Operative {i+1}",
                "alive": True
            })

    def is_team_alive(self):
        return any(op["alive"] for op in self.operatives)

    def get_alive_operatives(self):
        return [op for op in self.operatives if op["alive"]]

    def kill(self, index):
        if 0 <= index < len(self.operatives):
            self.operatives[index]["alive"] = False
