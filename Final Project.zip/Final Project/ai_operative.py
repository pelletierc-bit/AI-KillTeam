import random

class AIOperative:
    def __init__(self, name, health=12, morale=8, aggression=5,
                 range_to_target=12, armor_save=4, objective_skill=4,
                 initiative_bonus=0):

        self._name = name
        self._health = health
        self._morale = morale
        self._aggression = aggression
        self._range_to_target = range_to_target
        self._armor_save = armor_save
        self._objective_skill = objective_skill
        self._initiative_bonus = initiative_bonus

    # ---------- properties ----------

    @property
    def name(self):
        return self._name

    @property
    def health(self):
        return self._health

    @health.setter
    def health(self, value):
        self._health = max(0, value)

    @property
    def morale(self):
        return self._morale

    @morale.setter
    def morale(self, value):
        self._morale = max(0, value)

    @property
    def armor_save(self):
        return self._armor_save

    # ---------- RANGE GETTER + SETTER ----------

    @property
    def range_to_target(self):
        return self._range_to_target

    @range_to_target.setter
    def range_to_target(self, value):
        self._range_to_target = max(0, value)

    # ---------- core ----------

    def take_damage(self, amount):
        self.health -= amount

    def adjust_morale(self, amount):
        self.morale += amount

    # ---------- dice ----------

    def roll(self, sides=6, times=1):
        if times == 1:
            return random.randint(1, sides)
        return [random.randint(1, sides) for _ in range(times)]

    def roll_save(self, incoming_damage):
        roll = self.roll()
        saved = roll >= self.armor_save
        damage_taken = 0 if saved else incoming_damage

        if damage_taken > 0:
            self.take_damage(damage_taken)
            self.adjust_morale(-1)

        return {
            "roll": roll,
            "saved": saved,
            "damage_taken": damage_taken,
            "health_after": self.health,
            "morale_after": self.morale,
        }

    def player_attack(self, hit: bool, damage: int):
        if not hit:
            return {
                "hit": False,
                "damage_reported": damage,
                "save_roll": None,
                "saved": None,
                "damage_taken": 0,
                "health_after": self.health,
                "morale_after": self.morale,
            }

        save_result = self.roll_save(damage)
        return {
            "hit": True,
            "damage_reported": damage,
            "save_roll": save_result["roll"],
            "saved": save_result["saved"],
            "damage_taken": save_result["damage_taken"],
            "health_after": save_result["health_after"],
            "morale_after": save_result["morale_after"],
        }

    # ---------- AI Attack ----------

    def ai_attack(self):
        hit_roll = self.roll()
        hit = hit_roll >= 4

        if not hit:
            return {"hit": False, "hit_roll": hit_roll, "damage": 0}

        damage = self.roll(sides=3)
        return {"hit": True, "hit_roll": hit_roll, "damage": damage}

    # ---------- Movement (does NOT change range directly) ----------

    def move_toward(self, inches=3):
        return inches

    def move_away(self, inches=3):
        return inches

    # ---------- Terrain & Positioning ----------

    def decide_terrain_action(self, climbable, climb_distance, height_advantage, enemy_distance):
        if self.health <= 4 or self.morale <= 4:
            return "retreat"

        if climbable and height_advantage and climb_distance <= 3:
            return "climb"

        if enemy_distance > 0:
            return "advance"

        return "stay"

    def climb(self):
        return "climbed"
