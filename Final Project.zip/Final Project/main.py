from ai_team import AITeam
from player_team import PlayerTeam

def parse_player_input(text):
    text = text.lower().strip()

    if text.startswith("hit"):
        parts = text.split(":")
        if len(parts) < 2:
            damage = 0
        else:
            try:
                damage = int(parts[1].strip().split()[0])
            except:
                damage = 0
        return True, damage

    if text.startswith("miss"):
        return False, 0

    return None, None


def main():

    # PLAYER TEAM SIZE
    while True:
        try:
            pcount = int(input("How many operatives are on YOUR team? "))
            if pcount >= 1:
                break
            print("Enter at least 1.")
        except:
            print("Invalid input.")

    player_team = PlayerTeam(count=pcount)

    # AI TEAM SIZE
    while True:
        try:
            count = int(input("How many AI operatives? (1–20): "))
            if 1 <= count <= 20:
                break
            print("Enter a number between 1 and 20.")
        except:
            print("Invalid input.")

    team = AITeam(count=count)

    print("\nAI Team Ready:")
    for op in team.operatives:
        print(f"- {op.name}: {op.health} HP")

    # -------------------------
    # GAME LOOP
    # -------------------------
    while team.is_team_alive() and player_team.is_team_alive():

        # ============================================================
        # POSITIONING PHASE
        # ============================================================
        in_attack_range = False

        while not in_attack_range:

            print("\n==============================")
            print("      POSITIONING PHASE")
            print("==============================")

            attacker = team.get_alive_operatives()[0]
            alive_players = player_team.get_alive_operatives()

            # -------------------------
            # ENTER ALL PLAYER DISTANCES
            # -------------------------
            player_distances = {}
            print("\nEnter the distance to EACH player operative (after their movement):")
            for i, op in enumerate(alive_players, start=1):
                try:
                    dist = int(input(f"Distance to {op['name']}: "))
                except:
                    dist = 999
                player_distances[i] = dist

            # -------------------------
            # DETERMINE CLOSEST ENEMY
            # -------------------------
            closest_op_index = min(player_distances, key=player_distances.get)
            closest_distance = player_distances[closest_op_index]
            closest_op_name = alive_players[closest_op_index - 1]["name"]

            attacker.range_to_target = closest_distance

            print(f"\nClosest enemy is {closest_op_name} at {closest_distance}\".")

            # -------------------------
            # TERRAIN INPUT
            # -------------------------
            climbable = input("Is there climbable terrain nearby? (y/n): ").strip().lower() == "y"

            climb_distance = 0
            height_advantage = False

            if climbable:
                try:
                    climb_distance = int(input("How high is the climb (in inches)? "))
                except:
                    climb_distance = 0

                height_advantage = input("Does climbing give height advantage? (y/n): ").strip().lower() == "y"

            # -------------------------
            # AI DECISION
            # -------------------------
            action = attacker.decide_terrain_action(
                climbable,
                climb_distance,
                height_advantage,
                closest_distance
            )

            ai_base_move = 3
            ai_move = 0

            if action == "climb":
                climb_height = climb_distance
                remaining_move = ai_base_move - climb_height
                if remaining_move < 0:
                    remaining_move = 0

                attacker.climb()
                print(f"{attacker.name} CLIMBS {climb_height}\" and moves {remaining_move}\" afterward.")

                attacker.range_to_target -= remaining_move
                ai_move = remaining_move

            elif action == "retreat":
                ai_move = ai_base_move
                attacker.range_to_target += ai_move
                print(f"{attacker.name} RETREATS {ai_move}\".")

            elif action == "advance":
                ai_move = ai_base_move
                attacker.range_to_target -= ai_move
                print(f"{attacker.name} ADVANCES {ai_move}\".")

            else:
                print(f"{attacker.name} HOLDS POSITION.")

            print(f"New calculated range: {attacker.range_to_target}\"")

            in_attack_range = attacker.range_to_target <= 6

            if not in_attack_range:
                print("\nNo one is in range. Repeating Positioning Phase...")

        # ============================================================
        # SHOOTING PHASE
        # ============================================================

        print("\n==============================")
        print("        SHOOTING PHASE")
        print("==============================")

        alive_ops = team.get_alive_operatives()

        print("\nChoose a target:")
        for i, op in enumerate(alive_ops):
            print(f"{i+1}. {op.name} (Health: {op.health})")

        try:
            choice = int(input("Target number: ")) - 1
            target_op = alive_ops[choice]
        except:
            print("Invalid choice.")
            continue

        user = input("Your attack (hit: X damage OR miss): ").strip()
        hit, dmg = parse_player_input(user)

        if hit is None:
            print("Invalid input.")
            continue

        result = target_op.player_attack(hit, dmg)

        if not result["hit"]:
            print(f"You missed {target_op.name}.")
        else:
            print(f"You hit {target_op.name} for {result['damage_reported']} damage.")
            print(f"{target_op.name} rolled {result['save_roll']} -> "
                  f"{'saved' if result['saved'] else 'failed'}")
            print(f"{target_op.name} took {result['damage_taken']} damage.")

        print(f"{target_op.name} now has {target_op.health} HP.")

        if not team.is_team_alive():
            print("\nAll AI operatives are down. You win.")
            break

        print("\nAI's Shooting Phase...")

        if attacker.range_to_target <= 6:
            ai_result = attacker.ai_attack()

            # AI targets the closest player operative
            ai_target = alive_players[closest_op_index - 1]

            if not ai_result["hit"]:
                print(f"{attacker.name} rolled {ai_result['hit_roll']} and MISSED.")
            else:
                print(f"{attacker.name} rolled {ai_result['hit_roll']} and HIT!")
                print(f"AI deals {ai_result['damage']} damage to {ai_target['name']}.")
                print("Apply this damage manually.")

                dead = input(f"Did {ai_target['name']} die? (y/n): ").strip().lower()
                if dead == "y":
                    index = player_team.operatives.index(ai_target)
                    player_team.kill(index)
                    print(f"{ai_target['name']} is now dead.")
        else:
            print(f"{attacker.name} is OUT OF RANGE and cannot attack.")

    print("\nGame Over.")


if __name__ == "__main__":
    main()
